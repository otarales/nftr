<footer class="page-footer font-small blue">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2022 Copyright:
    <a href="../index.php">Home</a>
    <a href="../contact.php">Contact</a>

    </div>
    <!-- Copyright -->

    </footer>